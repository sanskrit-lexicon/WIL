php wiltab_mw.php  wiltab_dump.txt  wiltab_mw-known-2a.txt   wiltab_mw-3-3.txt regexp-1-ma.txt > wiltab_mw-3-3.log
